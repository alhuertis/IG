#ifndef Copo_H
#define Copo_H
#include <Windows.h>
#include <gl/GL.h>
#include <gl/GLU.h>
#include <GL/freeglut.h>
#include <list>
#include "segmento.h"
#include "lapiz.h"


#include <iostream>
using namespace std;

class Copo {

private:
	
	std::list<Segmento> lista;
	

public:

	Copo::Copo(GLdouble centroX, GLdouble centroY, double longitud, double alturaTriangulo){
		
		PV2D tr1= PV2D(centroX-longitud, centroY-(alturaTriangulo/2));
		PV2D tr2= PV2D(centroX, centroY+(alturaTriangulo/2));
		PV2D tr3= PV2D(centroX+longitud, centroY-(alturaTriangulo/2));

		Segmento ini= Segmento(tr1,tr2,60);
		Segmento md= Segmento(tr2,tr3,-60);
		Segmento fin= Segmento(tr3,tr1,180);

		lista.push_back(ini);
		lista.push_back(md);
		lista.push_back(fin);
	}
	
	~Copo(){}

	std::list<Segmento> Copo::getList(){return lista;}

	void Copo::construyeAlgoritmo(void){
		int auxListas= lista.size();

		for(int i=0; i < auxListas; i++){
			Segmento aux = lista.front();
			lista.pop_front();
			construyeP(aux);
		}
		
	}


	void Copo::construyeP(Segmento s){

		Lapiz x= Lapiz(&s.GetIni(), s.GetGrad());
		int longitud= s.calcularDist(s.GetIni(), s.GetFin())/3;
		x.forward(longitud, true);
		Segmento uno= Segmento(s.GetIni(), x.GetPos(), x.GetDir());
		lista.push_back(uno);
		x.turnTo(+60);
		x.forward(longitud, true);
		Segmento dos= Segmento(uno.GetFin(), x.GetPos(), x.GetDir());
		lista.push_back(dos);
		x.turnTo(-120);
		x.forward(longitud, true);
		Segmento tres= Segmento(dos.GetFin(), x.GetPos(), x.GetDir());
		lista.push_back(tres);
		x.turnTo(60);
		x.forward(longitud, true);
		Segmento cuatro= Segmento(tres.GetFin(), x.GetPos(), x.GetDir());
		lista.push_back(cuatro);
		

	}


} ;
#endif